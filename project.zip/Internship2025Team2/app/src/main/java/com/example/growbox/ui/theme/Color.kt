package com.example.growbox.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)


val GreenLight = Color(0xFF53C904)

val Green800 = Color(0xFF2F7302)   // #2F7302
val Green200 = Color(0xFFD5E3CC)   // #D5E3CC
val Green300 = Color(0xFF97B980)   // #97B980
val Gray999 = Color(0x99999999) // 99 - альфа ~60% прозорості
val Black = Color(0xFF020202)
val White = Color(0xFFE0E0E0)