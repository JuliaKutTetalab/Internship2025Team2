package com.example.growbox.screen.home.chart



import androidx.lifecycle.viewModelScope
import com.example.growbox.R
import com.example.growbox.data.GrowBoxRepository
import com.example.growbox.data.model.OfflineRepository
import com.example.growbox.screen.home.chart.model.ChartType
import com.example.growbox.screen.home.chart.model.ChartUiState
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import com.example.growbox.screen.home.chart.model.ChartDataPoint
import com.example.growbox.screen.home.chart.model.ChartPeriod




import android.util.Log
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter



class ChartViewModel(
    savedStateHandle: SavedStateHandle,
    private val growBoxRepository: GrowBoxRepository,
    private val offlineRepository: OfflineRepository
) : ViewModel() {

    private fun debugSummary(tag: String, list: List<ChartDataPoint>) {
        val nonMissing = list.count { !it.isMissing }
        val nonZero = list.count { it.value != 0f }
        val min = list.minOfOrNull { it.value }
        val max = list.maxOfOrNull { it.value }

        Log.d(tag, "size=${list.size} nonMissing=$nonMissing nonZero=$nonZero min=$min max=$max")
    }

    private var cropStartedAtMillis: Long? = null
    private var cropCurrentDay: Int? = null

    private val cropId: String = savedStateHandle[ChartDestination.cropIdArg] ?: ""
    private val initialType: String = savedStateHandle[ChartDestination.chartTypeArg] ?: "LIGHT"

    private val chartType: ChartType = runCatching { ChartType.valueOf(initialType) }
        .getOrElse { ChartType.LIGHT }

    private val currentUserId: String = growBoxRepository.getCurrentUserId() ?: ""

    private val _uiState = MutableStateFlow(ChartUiState(chartType = chartType))
    val uiState: StateFlow<ChartUiState> = _uiState.asStateFlow()

    private var allHistory: List<ChartDataPoint> = emptyList()
    private var allHourly: List<ChartDataPoint> = emptyList()

    private var historyJob: Job? = null
    private var hourlyJob: Job? = null
    private var cropJob: Job? = null

    // ---------- date helpers ----------
    private val DATE_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    private fun String.toLocalDateOrNull(): LocalDate? =
        runCatching { LocalDate.parse(this.trim(), DATE_FMT) }.getOrNull()

    private fun LocalDate.toIsoString(): String = format(DATE_FMT)

    private fun dayOfWeekShort(date: LocalDate): String = when (date.dayOfWeek.value) {
        1 -> "Mon"
        2 -> "Tue"
        3 -> "Wed"
        4 -> "Thu"
        5 -> "Fri"
        6 -> "Sat"
        else -> "Sun"
    }

    /**
     * ✅ AnchorDate выбираем так:
     * 1) если в history есть даты — берём максимальную (самая свежая)
     * 2) иначе startedAt + (currentDay-1)
     * 3) иначе today
     *
     * Это даёт стабильную привязку окна и правильные нижние даты.
     */
    private fun resolveAnchorDate(
        startedAtMillis: Long?,
        currentDay: Int?,
        history: List<ChartDataPoint>
    ): LocalDate {
        val zone = ZoneId.systemDefault()

        val lastFromHistory = history
            .mapNotNull { it.dataLabel.toLocalDateOrNull() }
            .maxOrNull()

        if (lastFromHistory != null) return lastFromHistory

        if (startedAtMillis != null && currentDay != null && currentDay > 0) {
            val started = Instant.ofEpochMilli(startedAtMillis).atZone(zone).toLocalDate()
            return started.plusDays((currentDay - 1).toLong())
        }

        return LocalDate.now(zone)
    }
    // --------------------------------

    init {
        if (cropId.isNotEmpty()) {
            setupInitialConfiguration()
            observeCropData()
            observeHistory()

            if (_uiState.value.selectedPeriod == ChartPeriod.DAY) observeHourly()

            applyPeriodToUi()
        }
    }

    fun onPeriodSelected(period: ChartPeriod) {
        _uiState.update { it.copy(selectedPeriod = period) }

        if (period == ChartPeriod.DAY) observeHourly() else hourlyJob?.cancel()

        applyPeriodToUi()
    }

    private fun observeCropData() {
        if (currentUserId.isEmpty()) return

        cropJob?.cancel()
        cropJob = viewModelScope.launch {
            offlineRepository.getCropStream(currentUserId).collect { crop ->
                crop ?: return@collect

                // ✅ ВАЖНО: сначала присвоили, потом логируем
                cropStartedAtMillis = crop.startedAt?.toDate()?.time
                cropCurrentDay = crop.currentDay

                Log.d(
                    "CROP_DEBUG",
                    "cropId=${crop.cropId} startedAtRaw=${crop.startedAt} " +
                            "startedAtMillis=$cropStartedAtMillis currentDay=$cropCurrentDay"
                )

                val value = when (chartType) {
                    ChartType.LIGHT -> crop.light
                    ChartType.TEMPERATURE -> crop.temperature
                    ChartType.HUMIDITY -> crop.humidity
                    ChartType.NUTRITION -> crop.nutrition
                }

                val recommended = when (chartType) {
                    ChartType.LIGHT -> crop.lightRecommended
                    ChartType.TEMPERATURE -> crop.tempRecommended
                    ChartType.HUMIDITY -> crop.humidityRecommended
                    ChartType.NUTRITION -> crop.nutritionRecommended
                }

                _uiState.update { it.copy(currentValue = value, recommendedValue = recommended) }

                // ✅ после получения crop — пересчитать окно
                applyPeriodToUi()
            }
        }
    }

    private fun observeHistory() {
        if (currentUserId.isEmpty()) return


        historyJob?.cancel()
        historyJob = viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }


            growBoxRepository.getCropHistory(currentUserId, cropId, chartType)
                .collect { points ->

                    Log.d("HISTORY_DEBUG", "chartType=$chartType")

                    debugSummary("HISTORY_SUMMARY", points)

                    points
                        .sortedBy { it.dataLabel.trim() }
                        .take(5)
                        .forEach {
                            Log.d("HISTORY_FIRST", "date=${it.dataLabel} value=${it.value} miss=${it.isMissing}")
                        }

                    // сортируем по yyyy-MM-dd (строка)
                    allHistory = points.sortedBy { it.dataLabel.trim() }

                    applyPeriodToUi()

                    _uiState.update { it.copy(isLoading = false) }
                }
        }
    }

    private fun observeHourly() {


        if (currentUserId.isEmpty()) return

        hourlyJob?.cancel()



        hourlyJob = viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            growBoxRepository.getCropHourly(currentUserId, cropId, chartType)
                .collect { points ->
                    Log.d("HOURLY_DEBUG", "chartType=$chartType")

                    debugSummary("HOURLY_SUMMARY", points)

                    points.take(5).forEach {
                        Log.d("HOURLY_FIRST", "hour=${it.hour} value=${it.value} miss=${it.isMissing}")
                    }

                    allHourly = points.sortedBy { it.hour ?: 0 }

                    // ✅ небольшой лог
                    Log.d("HOURLY_DEBUG", "hourly size=${allHourly.size} hours=${allHourly.map { it.hour }.distinct()}")

                    applyPeriodToUi()

                    _uiState.update { it.copy(isLoading = false) }
                }
        }
    }

    private fun applyPeriodToUi() {
        val period = _uiState.value.selectedPeriod

        val window = when (period) {
            ChartPeriod.DAY -> buildDayWindow(allHourly)
            ChartPeriod.WEEK -> buildWeekWindow(allHistory)
            ChartPeriod.MONTH -> buildMonthWindow(allHistory)
        }
        Log.d("TEMP_DEBUG", "period=$period type=$chartType window=" +
                window.joinToString { "${it.dataLabel}:${it.value} miss=${it.isMissing}" }
        )


        // ✅ (2) ЛОГ anchorDate и окна (чтобы ловить “не те даты”)
        val anchor = resolveAnchorDate(cropStartedAtMillis, cropCurrentDay, allHistory)
        Log.d(
            "WINDOW_DEBUG",
            "period=$period anchor=$anchor " +
                    "startedAtMillis=$cropStartedAtMillis currentDay=$cropCurrentDay " +
                    "windowSize=${window.size} nonMissing=${window.count { !it.isMissing }} " +
                    "firstDate=${window.firstOrNull()?.dataLabel} lastDate=${window.lastOrNull()?.dataLabel}"
        )

        val usageUnit = when (chartType) {
            ChartType.LIGHT -> "kw"
            ChartType.TEMPERATURE -> "kw"
            ChartType.HUMIDITY -> "ml"
            ChartType.NUTRITION -> "mg"
        }
        Log.d("WINDOW_TYPE", "chartType=$chartType period=$period")
        debugSummary("WINDOW_SUMMARY", window)

        window.take(5).forEach {
            Log.d("WINDOW_FIRST", "date=${it.dataLabel} value=${it.value} miss=${it.isMissing}")
        }

        val periodSum = window.sumOf { it.usageValue.toDouble() }.toFloat()
        val totalSum = allHistory.sumOf { it.usageValue.toDouble() }.toFloat()

        _uiState.update {
            it.copy(
                chartData = window,
                weekConsumption = "${periodSum.toInt()} $usageUnit",
                totalConsumption = "${totalSum.toInt()} $usageUnit",
                weekValue = "${periodSum.toInt()} $usageUnit",
                totalValue = "${totalSum.toInt()} $usageUnit"
            )
        }
    }

    // --------- WINDOWS (fixed size) ----------

    private fun buildDayWindow(hourly: List<ChartDataPoint>): List<ChartDataPoint> {
        val mapByHour = hourly.associateBy { it.hour }
        val labels = mapOf(0 to "0", 6 to "6", 12 to "12", 18 to "18", 23 to "24")

        // ✅ всегда 24
        return (0..23).map { h ->
            val p = mapByHour[h]
            if (p != null) {
                p.copy(
                    hour = h,
                    dayLabel = labels[h] ?: "",
                    dataLabel = "",
                    isMissing = p.isMissing
                )
            } else {
                ChartDataPoint(
                    value = 0f,
                    dayLabel = labels[h] ?: "",
                    dataLabel = "",
                    usageValue = 0f,
                    hour = h,
                    isMissing = true
                )
            }
        }
    }

    private fun buildWeekWindow(history: List<ChartDataPoint>): List<ChartDataPoint> {
        val anchor = resolveAnchorDate(cropStartedAtMillis, cropCurrentDay, history)
        val start = anchor.minusDays(6)

        val byDate = history.mapNotNull { p ->
            val d = p.dataLabel.toLocalDateOrNull() ?: return@mapNotNull null
            d to p
        }.toMap()

        return (0..6).map { offset ->
            val d = start.plusDays(offset.toLong())
            val fromDb = byDate[d]

            val base = fromDb ?: ChartDataPoint(
                value = 0f,
                dayLabel = "",
                dataLabel = d.toIsoString(),  // ✅ всегда есть дата
                usageValue = 0f,
                hour = null,
                isMissing = true
            )

            base.copy(
                dayLabel = dayOfWeekShort(d),
                dataLabel = d.toIsoString(),
                isMissing = fromDb == null
            )
        }
    }


    private fun buildMonthWindow(history: List<ChartDataPoint>): List<ChartDataPoint> {
        val anchor = resolveAnchorDate(cropStartedAtMillis, cropCurrentDay, history)
        val start = anchor.minusDays(29)

        val byDate = history.mapNotNull { p ->
            val d = p.dataLabel.toLocalDateOrNull() ?: return@mapNotNull null
            d to p
        }.toMap()

        // показываем 7 подписей снизу в этих позициях
        val showPos = setOf(0, 4, 9, 14, 19, 24, 29)

        return (0..29).map { idx ->
            val d = start.plusDays(idx.toLong())
            val fromDb = byDate[d]

            val base = fromDb ?: ChartDataPoint(
                value = 0f,
                dayLabel = "",
                dataLabel = d.toIsoString(),   // ✅ ДАТА ЕСТЬ ДАЖЕ У MISSING
                usageValue = 0f,
                hour = null,
                isMissing = true
            )

            base.copy(
                // dayLabel можно использовать или нет — но пусть будет полезно
                dayLabel = if (idx in showPos) d.dayOfMonth.toString() else "",
                dataLabel = d.toIsoString(),
                isMissing = fromDb == null
            )
        }
    }


    // ----------------------------------------------

    private fun setupInitialConfiguration() {
        _uiState.update { state ->
            when (chartType) {
                ChartType.LIGHT -> state.copy(
                    unit = "%",
                    iconRes = R.drawable.ic_light_icon,
                    titleRes = R.string.light_title,
                    consumptionUnit = "kw"
                )
                ChartType.TEMPERATURE -> state.copy(
                    unit = "°C",
                    iconRes = R.drawable.ic_temperature_icon,
                    titleRes = R.string.temperature_title,
                    consumptionUnit = "kw"
                )
                ChartType.HUMIDITY -> state.copy(
                    unit = "%",
                    iconRes = R.drawable.ic_humidity_icon,
                    titleRes = R.string.humidity_title,
                    consumptionUnit = "ml"
                )
                ChartType.NUTRITION -> state.copy(
                    unit = "%",
                    iconRes = R.drawable.ic_nutrition_icon,
                    titleRes = R.string.nutrition_title,
                    consumptionUnit = "mg"
                )
            }
        }
    }

    override fun onCleared() {
        historyJob?.cancel()
        hourlyJob?.cancel()
        cropJob?.cancel()
        super.onCleared()
    }
}
