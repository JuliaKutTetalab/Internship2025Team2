package com.example.growbox.screen.profile.my_harvest.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.growbox.ui.theme.GreenLight



@Composable
fun HarvestCard(
    cropType: String,
    harvests: Int,
    totalDays: Int
) {

    val cardBackground = Color(0xFFF1F4F3)
    val numberColor = Color(0xFF2E7D32)
    val textColor = Color.Black

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = cardBackground
        ),
        elevation = CardDefaults.cardElevation(6.dp),
        modifier = Modifier
            .fillMaxWidth()
    ) {

        Column(
            modifier = Modifier
                .padding(20.dp),
            horizontalAlignment = Alignment.Start
        ) {


            Box(
                modifier = Modifier
                    .size(70.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE5ECEA)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Eco,
                    contentDescription = null,
                    tint = GreenLight,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))


            Text(
                text = cropType,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = GreenLight
            )

            Spacer(modifier = Modifier.height(12.dp))


            Row {
                Text(
                    text = "Harvests: ",
                    fontSize = 16.sp,
                    color = textColor
                )
                Text(
                    text = harvests.toString(),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = numberColor
                )
            }

            Spacer(modifier = Modifier.height(6.dp))


            Row {
                Text(
                    text = "Total Days: ",
                    fontSize = 16.sp,
                    color = textColor
                )
                Text(
                    text = totalDays.toString(),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = numberColor
                )
            }
        }
    }
}
