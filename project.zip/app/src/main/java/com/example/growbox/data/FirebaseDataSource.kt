package com.example.growbox.data


import com.example.growbox.data.model.Crop
import com.example.growbox.data.model.User
import com.example.growbox.screen.home.chart.model.ChartDataPoint
import com.example.growbox.screen.home.chart.model.ChartType
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

import com.google.firebase.Timestamp
import kotlinx.coroutines.tasks.await
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Date

interface FirebaseDataSource {


    // Операції Auth
    suspend fun registerUser(email: String, password: String): String
    suspend fun signIn(email: String, password: String): String
    suspend fun isLoggedIn(): Boolean
    fun getCurrentUserId(): String?





    suspend fun createUserProfile(userId: String, email: String)
    suspend fun saveNewCrop(userId: String, crop: Crop)
    suspend fun fetchCurrentCrop(userId: String): Crop?


    suspend fun seedCropMock_2026_02_05_to_02_16(userId: String)




    suspend fun updateCropField(userId: String, cropId: String, field: String, value: Any)
    fun getCurrentUserEmail(): String?
    suspend fun signOut()
    suspend fun fetchCropHistory(userId: String, cropId: String, type: ChartType): List<ChartDataPoint>

    suspend fun fetchCropHourly(userId: String, cropId: String, type: ChartType): List<ChartDataPoint>

}

class FirebaseDataSourceImpl(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) : FirebaseDataSource {

    private val DATE_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    companion object {
        const val USERS_COLLECTION = "users"
        const val CROPS_COLLECTION = "crops"

        const val HOUR_COLLECTION = "hourly"
    }


    override suspend fun seedCropMock_2026_02_05_to_02_16(userId: String) {
        val cropId = "testCrop" // стабильно для тестов
        val zone = ZoneId.systemDefault()

        val cropsRef = firestore.collection(USERS_COLLECTION)
            .document(userId)
            .collection(CROPS_COLLECTION)

        val cropRef = cropsRef.document(cropId)
        val historyRef = cropRef.collection("history")
        val hourlyRef = cropRef.collection(HOUR_COLLECTION)



        // Диапазон дат
        val startDate = LocalDate.of(2026, 2, 5)
        val endDate = LocalDate.of(2026, 2, 16)
        val daysCount = java.time.temporal.ChronoUnit.DAYS.between(startDate, endDate).toInt() + 1 // 12

        // startedAt/endsAt как Timestamp
        val startedAtZdt: ZonedDateTime = startDate.atStartOfDay(zone)
        val endsAtZdt: ZonedDateTime = endDate.atTime(23, 59, 59).atZone(zone)

        val startedAtTs = Timestamp(Date(startedAtZdt.toInstant().toEpochMilli()))
        val endsAtTs = Timestamp(Date(endsAtZdt.toInstant().toEpochMilli()))

        // ✅ CROP со ВСЕМИ твоими полями
        val cropDoc = hashMapOf(
            "cropId" to cropId,
            "userId" to userId,
            "cropType" to "Herbs",
            "status" to "Active",
            "currentDay" to 3,
            "totalDays" to 21,

            "startedAt" to startedAtTs,
            "endsAt" to endsAtTs,

            "temperature" to 57,
            "humidity" to 33,
            "light" to 32,
            "nutrition" to 202,

            "isVentOn" to true,
            "isWateringOn" to true,
            "ventHours" to 49,
            "isLightOn" to false,
            "watering" to 330,

            "lightRecommended" to 72,
            "tempRecommended" to 26,
            "humidityRecommended" to 74,
            "nutritionRecommended" to 65
        )

        cropRef.set(cropDoc).await()

        // ===== HISTORY: 12 дней подряд =====
        for (i in 0 until daysCount) {
            val d = startDate.plusDays(i.toLong())
            val dateStr = d.format(DATE_FMT)

            // значения “красивой волной”, чтобы график был интересный
            val light = (20 + (i * 7)) % 100
            val temp = 18 + (i % 10)
            val hum = 35 + (i * 2)
            val nutr = 160 + (i * 4)

            val dayLabel = d.dayOfWeek.name.take(3).lowercase()
                .replaceFirstChar { it.uppercase() } // Mon Tue...

            val historyDoc = hashMapOf(
                "date" to dateStr,
                "dayLabel" to dayLabel,

                "light" to light,
                "temperature" to temp,
                "humidity" to hum,
                "nutrition" to nutr,

                // usage (если ты где-то используешь)
                "lightUsage" to (1..10).random(),
                "tempUsage" to (10..40).random(),
                "waterUsage" to (10..80).random(),
                "nutritionUsage" to (1..50).random()
            )

            // ✅ docId = yyyy-MM-dd (важно для стабильности)
            historyRef.document(dateStr).set(historyDoc).await()
        }

        // ===== HOURLY: каждый день 24 часа =====
        for (dayIndex in 0 until daysCount) {
            val day = startDate.plusDays(dayIndex.toLong())
            val dayStart = day.atStartOfDay(zone)

            for (h in 0 until 24) {
                val zdt = dayStart.plusHours(h.toLong())
                val ts = Timestamp(Date(zdt.toInstant().toEpochMilli()))

                // делаем “ступеньки + пики”, чтобы day-график выглядел как реальный
                val light = when {
                    h in 0..5 -> 5 + h * 2
                    h in 6..11 -> 40 + (h - 6) * 8
                    h in 12..17 -> 90 - (h - 12) * 6
                    else -> 30 - (h - 18) * 4
                }.coerceIn(0, 100)

                val temp = (16 + (h % 10)).coerceIn(10, 35)
                val hum = (45 + (h % 20)).coerceIn(20, 90)
                val nutr = (150 + (h * 3) % 100).coerceIn(80, 260)

                val hourlyDoc = hashMapOf(
                    "createdAt" to ts,
                    "temperature" to temp,
                    "humidity" to hum,
                    "light" to light,
                    "nutrition" to nutr
                )

                hourlyRef.document().set(hourlyDoc).await()
            }
        }
    }


    override suspend fun fetchCropHourly(
        userId: String,
        cropId: String,
        type: ChartType
    ): List<ChartDataPoint> {

        val valueField = when (type) {
            ChartType.LIGHT -> "light"
            ChartType.TEMPERATURE -> "temperature"
            ChartType.HUMIDITY -> "humidity"
            ChartType.NUTRITION -> "nutrition"
        }

        val snapshot = firestore.collection(USERS_COLLECTION)
            .document(userId)
            .collection(CROPS_COLLECTION)
            .document(cropId)
            .collection(HOUR_COLLECTION)
            .orderBy("createdAt")
            .limitToLast(24)
            .get()
            .await()

        val rows = snapshot.documents.mapNotNull { doc ->
            val ts = doc.getTimestamp("createdAt")?.toDate() ?: return@mapNotNull null
            val value = doc.getDouble(valueField)?.toFloat() ?: 0f
            val cal = java.util.Calendar.getInstance().apply { time = ts }
            val hour = cal.get(java.util.Calendar.HOUR_OF_DAY) // 0..23
            Triple(hour, ts.time, value)
        }

        val lastByHour: Map<Int, Triple<Int, Long, Float>> =
            rows.groupBy { it.first }
                .mapValues { (_, list) -> list.maxBy { it.second } }

        return (0..23).map { h ->
            val triple = lastByHour[h]
            if (triple != null) {
                ChartDataPoint(
                    value = triple.third,
                    dayLabel = "",
                    dataLabel = "",
                    usageValue = 0f,
                    hour = h,
                    isMissing = false
                )
            } else {
                ChartDataPoint(
                    value = 0f,
                    dayLabel = "",
                    dataLabel = "",
                    usageValue = 0f,
                    hour = h,
                    isMissing = true
                )
            }
        }
    }






    override suspend fun fetchCropHistory(
        userId: String,
        cropId: String,
        type: ChartType
    ): List<ChartDataPoint> {

        val valueField = when (type) {
            ChartType.LIGHT -> "light"
            ChartType.TEMPERATURE -> "temperature"
            ChartType.HUMIDITY -> "humidity"
            ChartType.NUTRITION -> "nutrition"
        }

        val usageField = when (type) {
            ChartType.LIGHT -> "lightUsage"
            ChartType.TEMPERATURE -> "tempUsage"
            ChartType.HUMIDITY -> "waterUsage"      // если у тебя humidityUsage нет, а вода есть — оставь waterUsage
            ChartType.NUTRITION -> "nutritionUsage"
        }

        val snapshot = firestore.collection(USERS_COLLECTION)
            .document(userId)
            .collection(CROPS_COLLECTION)
            .document(cropId)
            .collection("history")
            .orderBy("date") // yyyy-MM-dd строка — сортируется нормально
            .get()
            .await()

        return snapshot.documents.mapNotNull { doc ->
            val dateStr = doc.getString("date")?.trim().orEmpty()
            if (dateStr.isBlank()) return@mapNotNull null

            val value = doc.getDouble(valueField)?.toFloat() ?: 0f
            val usage = doc.getDouble(usageField)?.toFloat() ?: 0f

            ChartDataPoint(
                value = value,
                dayLabel = "",          // dayLabel строим в VM сами
                dataLabel = dateStr,    // важно!
                usageValue = usage,
                hour = null,
                isMissing = false
            )
        }
    }




    override fun getCurrentUserEmail(): String? = auth.currentUser?.email

    override suspend fun signOut() {
        auth.signOut()
    }

    override suspend fun registerUser(email: String, password: String): String {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        return result.user?.uid ?: throw IllegalStateException("UID is null")
    }

    override suspend fun createUserProfile(userId: String, email: String) {
        val initialUser = User(
            userId = userId,
            email = email,
            farmName = "GrowBox-${userId.take(5)}"
        )
        firestore.collection(USERS_COLLECTION).document(userId).set(initialUser).await()
    }

    override suspend fun saveNewCrop(userId: String, crop: Crop) {
        firestore.collection(USERS_COLLECTION)
            .document(userId)
            .collection(CROPS_COLLECTION)
            .document(crop.cropId)
            .set(crop)
            .await()
    }

    override suspend fun isLoggedIn(): Boolean = withContext(Dispatchers.IO) {
        return@withContext auth.currentUser != null
    }

    override fun getCurrentUserId(): String? = auth.currentUser?.uid

    override suspend fun fetchCurrentCrop(userId: String): Crop? {
        val snapshot = firestore.collection(USERS_COLLECTION)
            .document(userId)
            .collection(CROPS_COLLECTION)
            .whereEqualTo("status", "Active")
            .limit(1)
            .get()
            .await()

        return snapshot.documents.firstOrNull()?.toObject(Crop::class.java)
    }

    override suspend fun updateCropField(userId: String, cropId: String, field: String, value: Any) {

        firestore.collection(USERS_COLLECTION)
            .document(userId)
            .collection(CROPS_COLLECTION)
            .document(cropId)
            .update(field, value)
            .await()
    }

    override suspend fun signIn(email: String, password: String): String {
        return suspendCoroutine { continuation ->
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val userId = task.result?.user?.uid
                        if (userId != null) continuation.resume(userId)
                        else continuation.resumeWithException(IllegalStateException("User ID is null"))
                    } else {
                        continuation.resumeWithException(task.exception ?: Exception("Sign-in failed"))
                    }
                }
        }
    }
}