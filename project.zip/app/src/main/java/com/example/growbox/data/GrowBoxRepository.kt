package com.example.growbox.data

import android.util.Log
import com.google.firebase.Timestamp
import com.example.growbox.data.model.Crop
import com.example.growbox.data.model.OfflineRepository
import com.example.growbox.data.model.User
import com.example.growbox.extension.calcGrownDays
import com.example.growbox.screen.home.chart.model.ChartDataPoint
import com.example.growbox.screen.home.chart.model.ChartType
import com.example.growbox.utils.calculateCurrentDay
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await




import java.util.Date
import java.util.UUID

interface GrowBoxRepository {
    suspend fun registerAndInitialize(email: String, password: String)
    suspend fun startNewCropCycle(userId: String, cropType: String)
    suspend fun signIn(email: String, password: String)
    suspend fun isLoggedIn(): Boolean
    fun getCurrentUserId(): String?


    suspend fun fetchCurrentCrop(userId: String): Crop?
    fun getCurrentUserEmail(): String?
    suspend fun signOut()
    fun getCropHistory(userId: String, cropId: String, type: ChartType): Flow<List<ChartDataPoint>>


    suspend fun updateVentStatus(userId: String, cropId: String, isOn: Boolean)
    suspend fun updateVentHours(userId: String, cropId: String, hours: Int)

    suspend fun updateLightStatus(userId: String, cropId: String, isOn: Boolean)
    suspend fun updateLightValue(userId: String, cropId: String, value: Int)

    suspend fun updateCurrentTemperature(userId: String, cropId: String, temp: Int)
    suspend fun updateCurrentHumidity(userId: String, cropId: String, humidity: Int)
    suspend fun updateNutritionValue(userId: String, cropId: String, mg: Int)

    suspend fun updateWateringStatus(userId: String, cropId: String, isOn: Boolean)

    suspend fun updateWateringValue(userId: String, cropId: String, value: Int)

    fun observeCropRealtime(userId: String)

    fun stopObserveCropRealtime()

    fun getLocalCropStream(userId: String): Flow<Crop?>

    suspend fun getLocalCropOnce(userId: String): Crop?


    suspend fun syncCropDay(userId: String, cropId: String)

    suspend fun markCropHarvested(userId: String, cropId: String)


    suspend fun harvestAndStartNewCycle(userId: String, newCropType: String)

    fun getAllCrops(userId: String): Flow<List<Crop>>

    suspend fun syncAllCrops(userId: String)

    fun getCropHourly(
        userId: String,
        cropId: String,
        type: ChartType
    ): Flow<List<ChartDataPoint>>

}

class GrowBoxRepositoryImpl(
    private val firebaseDataSource: FirebaseDataSource,
    private val offlineRepository: OfflineRepository,
    private val firestore: FirebaseFirestore
) : GrowBoxRepository {

    override fun getAllCrops(userId: String): Flow<List<Crop>> {
        return offlineRepository.getAllCropsStream(userId)
    }

    override fun getCropHourly(
        userId: String,
        cropId: String,
        type: ChartType
    ): Flow<List<ChartDataPoint>> = flow {
        try {
            val points = firebaseDataSource.fetchCropHourly(userId, cropId, type)
            emit(points)
        } catch (e: Exception) {
            Log.e("Repository", "Error fetching hourly", e)
            emit(emptyList())
        }
    }

    override suspend fun syncAllCrops(userId: String) {
        try {
            val snap = firestore.collection("users")
                .document(userId)
                .collection("crops")
                .get()
                .await()

            val crops = snap.documents.mapNotNull { doc ->
                doc.toObject(Crop::class.java)?.copy(cropId = doc.id)
            }

            crops.forEach { crop ->
                offlineRepository.insertCrop(crop, userId)
            }
            recalcUserTotals(userId)

        } catch (e: Exception) {
            Log.e("SYNC_ALL_CROPS", "Failed sync", e)
        }
    }

    override suspend fun harvestAndStartNewCycle(userId: String, newCropType: String) {
        val active = offlineRepository.getCropOnce(userId) ?: run {
            startNewCropCycle(userId, newCropType)
            return
        }

        val currentDay = calculateCurrentDay(active.startedAt, active.totalDays)
        val ready = currentDay >= active.totalDays
        if (!ready) throw IllegalStateException("Not ready to harvest")

        val now = Timestamp.now()


        val harvested = active.copy(
            status = "Harvested",
            currentDay = active.totalDays,
            endsAt = now
        )
        offlineRepository.insertCrop(harvested, userId)


        firebaseDataSource.updateCropField(userId, active.cropId, "status", "Harvested")
        firebaseDataSource.updateCropField(userId, active.cropId, "endsAt", now)


        startNewCropCycle(userId, newCropType)
        recalcUserTotals(userId)
    }

    override suspend fun markCropHarvested(userId: String, cropId: String) {
        updateCropLocalAndRemote(
            userId = userId,
            cropId = cropId,
            fieldName = "status",
            remoteValue = "Harvested"
        ) { it.copy(status = "Harvested") }
    }


    override suspend fun syncCropDay(userId: String, cropId: String) {
        val crop = offlineRepository.getCropOnce(userId) ?: return
        val started = crop.startedAt ?: return

        val nowMs = System.currentTimeMillis()
        val startedMs = started.toDate().time
        val daysPassed = ((nowMs - startedMs) / (24L * 60L * 60L * 1000L)).toInt()

        val newDay = (1 + daysPassed).coerceIn(1, crop.totalDays)
        val newStatus = if (newDay >= crop.totalDays) "Harvested" else "Active"


        if (newDay == crop.currentDay && newStatus == crop.status) return

        val updated = crop.copy(currentDay = newDay, status = newStatus)


        offlineRepository.insertCrop(updated, userId)

recalcUserTotals(userId)
        try {
            firebaseDataSource.updateCropField(userId, cropId, "currentDay", newDay)
            firebaseDataSource.updateCropField(userId, cropId, "status", newStatus)
        } catch (_: Exception) {}
    }

    override fun getLocalCropStream(userId: String): Flow<Crop?> {
        return offlineRepository.getCropStream(userId)
    }

    override suspend fun getLocalCropOnce(userId: String): Crop? {
        return offlineRepository.getCropOnce(userId)
    }

    private var cropListener: ListenerRegistration? = null


    override fun observeCropRealtime(userId: String) {
        cropListener?.remove()

        cropListener = firestore.collection("users")
            .document(userId)
            .collection("crops")
            .whereEqualTo("status", "Active")
            .limit(1)
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener

                val doc = snapshot?.documents?.firstOrNull() ?: return@addSnapshotListener
                val remote = doc.toObject(Crop::class.java)?.copy(cropId = doc.id) ?: return@addSnapshotListener

                CoroutineScope(Dispatchers.IO).launch {
                    val local = offlineRepository.getCropOnce(userId)


                    if (local != remote) {
                        offlineRepository.insertCrop(remote, userId)
                    }
                }
            }
    }




    override fun stopObserveCropRealtime() {
        cropListener?.remove()
        cropListener = null
    }



    private suspend fun updateCropLocalAndRemote(
        userId: String,
        cropId: String,
        fieldName: String,
        remoteValue: Any,
        updateLocal: (Crop) -> Crop
    ) {
        val localCrop = offlineRepository.getCropOnce(userId)
        localCrop?.let { current ->
            val updated = updateLocal(current)


            if (updated != current) {
                offlineRepository.insertCrop(updated, userId)
            }
        }

        try {
            firebaseDataSource.updateCropField(userId, cropId, fieldName, remoteValue)
        } catch (e: Exception) {
            Log.e("Repository", "Remote update failed", e)
        }
    }




    override suspend fun updateVentStatus(
        userId: String,
        cropId: String,
        isOn: Boolean
    ) {
        updateCropLocalAndRemote(
            userId,
            cropId,
            "isVentOn",
            isOn
        ) { it.copy(isVentOn = isOn) }
    }

    override suspend fun updateVentHours(
        userId: String,
        cropId: String,
        hours: Int
    ) {
        updateCropLocalAndRemote(
            userId,
            cropId,
            "ventHours",
            hours
        ) { it.copy(ventHours = hours) }
    }



    override suspend fun updateLightStatus(
        userId: String,
        cropId: String,
        isOn: Boolean
    ) {
        updateCropLocalAndRemote(
            userId,
            cropId,
            "isLightOn",
            isOn
        ) { it.copy(isLightOn = isOn) }
    }

    override suspend fun updateLightValue(
        userId: String,
        cropId: String,
        value: Int
    ) {
        updateCropLocalAndRemote(
            userId,
            cropId,
            "light",
            value
        ) { it.copy(light = value) }
    }



    override suspend fun updateCurrentTemperature(
        userId: String,
        cropId: String,
        temp: Int
    ) {
        updateCropLocalAndRemote(
            userId,
            cropId,
            "temperature",
            temp
        ) { it.copy(temperature = temp) }
    }

    override suspend fun updateCurrentHumidity(
        userId: String,
        cropId: String,
        humidity: Int
    ) {
        updateCropLocalAndRemote(
            userId,
            cropId,
            "humidity",
            humidity
        ) { it.copy(humidity = humidity) }
    }


    override suspend fun updateNutritionValue(
        userId: String,
        cropId: String,
        mg: Int
    ) {
        updateCropLocalAndRemote(
            userId,
            cropId,
            "nutrition",
            mg
        ) { it.copy(nutrition = mg) }
    }



    override suspend fun updateWateringStatus(
        userId: String,
        cropId: String,
        isOn: Boolean
    ) {
        updateCropLocalAndRemote(
            userId,
            cropId,
            "isWateringOn",
            isOn
        ) { it.copy(isWateringOn = isOn) }
    }

    override suspend fun updateWateringValue(
        userId: String,
        cropId: String,
        value: Int
    ) {
        updateCropLocalAndRemote(
            userId,
            cropId,
            "watering",
            value
        ) { it.copy(watering = value) }
    }



    override fun getCropHistory(
        userId: String,
        cropId: String,
        type: ChartType
    ): Flow<List<ChartDataPoint>> = flow {

        val localHistory =
            offlineRepository.getChartHistoryStream(cropId, type.name).first()
        emit(localHistory)

        try {
            val snapshots = firestore.collection("users")
                .document(userId)
                .collection("crops")
                .document(cropId)
                .collection("history")
                .orderBy("date")
                .get()
                .await()

            val remoteHistory = snapshots.documents.map { doc ->

                val usageField = when (type) {
                    ChartType.LIGHT -> "lightUsage"
                    ChartType.TEMPERATURE -> "tempUsage"
                    ChartType.HUMIDITY -> "waterUsage"
                    ChartType.NUTRITION -> "nutritionUsage"
                }

                val valueField = when (type) {
                    ChartType.LIGHT -> "light"
                    ChartType.TEMPERATURE -> "temperature"
                    ChartType.HUMIDITY -> "humidity"
                    ChartType.NUTRITION -> "nutrition"
                }

                ChartDataPoint(
                    value = doc.getDouble(valueField)?.toFloat() ?: 0f,
                    dayLabel = doc.getString("dayLabel") ?: "",
                    dataLabel = doc.getString("date") ?: "",
                    usageValue = doc.getDouble(usageField)?.toFloat() ?: 0f
                )

            }

            if (remoteHistory.isNotEmpty()) {
                offlineRepository.insertChartHistory(
                    cropId,
                    type.name,
                    remoteHistory
                )
                emit(remoteHistory)
            }

        } catch (e: Exception) {
            Log.e("Repository", "Error fetching history", e)
        }
    }



    override suspend fun signOut() =
        firebaseDataSource.signOut()

    override suspend fun registerAndInitialize(
        email: String,
        password: String
    ) {
        val userId = firebaseDataSource.registerUser(email, password)
        firebaseDataSource.createUserProfile(userId, email)
      //  firebaseDataSource.seedCropMock_2026_02_05_to_02_16(userId)
        offlineRepository.insertUser(User(userId = userId, email = email))
    }


    override suspend fun startNewCropCycle(
        userId: String,
        cropType: String
    ) {
        val now = Timestamp.now()
        val ends = Timestamp(Date(System.currentTimeMillis() + 21L * 86_400_000L))

        val localActive = offlineRepository.getCropOnce(userId)

        if (localActive != null && localActive.cropId.isNotEmpty() && localActive.status == "Active") {

            val ready = isHarvestReady(localActive.startedAt, localActive.totalDays)
            if (!ready) {
                throw IllegalStateException("Crop is not ready to harvest yet")
            }


            val harvested = localActive.copy(
                status = "Harvested",
                currentDay = localActive.totalDays

            )


            offlineRepository.insertCrop(harvested, userId)


            firebaseDataSource.updateCropField(userId, localActive.cropId, "status", "Harvested")
            firebaseDataSource.updateCropField(userId, localActive.cropId, "currentDay", harvested.currentDay)

        }

        val newCropId = UUID.randomUUID().toString()
        val newCrop = Crop(
            cropId = newCropId,
            userId = userId,
            cropType = cropType,
            status = "Active",
            currentDay = 1,
            totalDays = 21,
            startedAt = now,
            endsAt = ends,
            temperature = 0,
            humidity = 0,
            light = 0,
            nutrition = 0,
            isVentOn = false,
            isWateringOn = false,
            ventHours = 0,
            isLightOn = false,
            watering = 0
        )

        firebaseDataSource.saveNewCrop(userId, newCrop)
        offlineRepository.insertCrop(newCrop, userId)
    }

    private fun isHarvestReady(startedAt: Timestamp?, totalDays: Int): Boolean {
        if (startedAt == null) return false
        val passedSec = Timestamp.now().seconds - startedAt.seconds
        val needSec = totalDays.toLong() * 86_400L
        return passedSec >= needSec
    }

    override suspend fun fetchCurrentCrop(userId: String): Crop? {
        return try {
            val snapshot = firestore.collection("users")
                .document(userId)
                .collection("crops")
                .whereEqualTo("status", "Active")
                .limit(1)
                .get()
                .await()

            val doc = snapshot.documents.firstOrNull()
            val crop = doc?.toObject(Crop::class.java)?.copy(cropId = doc.id)


            crop?.let { offlineRepository.insertCrop(it, userId) }
            crop
        } catch (e: Exception) {
            Log.e("Repository", "Error fetching crop", e)
            null
        }
    }


    override suspend fun signIn(email: String, password: String) {
        firebaseDataSource.signIn(email, password)
        val uid = getCurrentUserId() ?: return
        syncAllCrops(uid)
        fetchCurrentCrop(uid)
    }

    override suspend fun isLoggedIn(): Boolean =
        firebaseDataSource.isLoggedIn()

    override fun getCurrentUserId(): String? =
        firebaseDataSource.getCurrentUserId()

    override fun getCurrentUserEmail(): String? =
        firebaseDataSource.getCurrentUserEmail()

    private suspend fun recalcUserTotals(userId: String) {

        Log.d("USER_ID", "recalcUserTotals called with userId=$userId")

        val crops = offlineRepository.getAllCropsStream(userId).first()

        val totalHarvestCount = crops.count { it.status.equals("Harvested", ignoreCase = true) }
        val totalDaysGrown = crops.sumOf { calcGrownDays(it) }

        Log.d("USER_TOTALS", "harvest=$totalHarvestCount days=$totalDaysGrown")

        try {
            firestore.collection("users")
                .document(userId)
                .set(
                    mapOf(
                        "totalHarvestCount" to totalHarvestCount,
                        "totalDaysGrown" to totalDaysGrown
                    ),
                    SetOptions.merge()
                )
                .await()

            Log.d("USER_TOTALS", "Firestore updated for userId=$userId")

        } catch (e: Exception) {
            Log.e("USER_TOTALS", "Failed to update firestore totals", e)
        }
    }
}




