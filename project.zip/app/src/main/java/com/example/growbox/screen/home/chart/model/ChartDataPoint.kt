package com.example.growbox.screen.home.chart.model

//data class ChartDataPoint(
//    val value: Float,
//    val dayLabel: String, //Mon, Tue, Wed, ...
//    val dataLabel: String,
//    val usageValue: Float = 0f
//)

data class ChartDataPoint(
    val value: Float = 0f,
    val dayLabel: String = "",
    val dataLabel: String = "", // для WEEK/MONTH тут будет yyyy-MM-dd
    val usageValue: Float = 0f,
    val hour: Int? = null,      // для DAY: 0..23
    val isMissing: Boolean = false
)


