package com.example.growbox.screen.profile.historic_data.model

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.growbox.data.GrowBoxRepository
import com.example.growbox.data.model.OfflineRepository
import com.example.growbox.screen.home.chart.model.ChartPeriod
import com.example.growbox.screen.home.chart.model.ChartType
import com.example.growbox.screen.profile.historic_data.chart_screen.HistoricChartUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class HistoricChartViewModel(
    private val growBoxRepository: GrowBoxRepository,
    private val offlineRepository: OfflineRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val userId = growBoxRepository.getCurrentUserId().orEmpty()

    private val _chartType: ChartType =
        savedStateHandle.get<String>("chartType")?.let { ChartType.valueOf(it) } ?: ChartType.LIGHT

    val chartType: ChartType get() = _chartType

    private val _uiState = MutableStateFlow(HistoricChartUiState())
    val uiState: StateFlow<HistoricChartUiState> = _uiState.asStateFlow()

    init {
        observe()
    }

    fun onPeriodSelected(period: ChartPeriod) {
        _uiState.value = _uiState.value.copy(selectedPeriod = period)
    }

    private fun observe() {
        viewModelScope.launch {
            if (userId.isBlank()) {
                _uiState.value = HistoricChartUiState(isLoading = false)
                return@launch
            }

            val active = offlineRepository.getCropOnce(userId)
            val cropId = active?.cropId.orEmpty()

            if (cropId.isBlank()) {
                _uiState.value = HistoricChartUiState(isLoading = false)
                return@launch
            }

            val unit = when (_chartType) {
                ChartType.LIGHT -> "%"
                ChartType.TEMPERATURE -> "°"
                ChartType.HUMIDITY -> "%"
                ChartType.NUTRITION -> "mg"
            }

            growBoxRepository.getCropHistory(userId, cropId, _chartType)
                .map { full ->

                    val period = _uiState.value.selectedPeriod
                    val data = when (period) {
                        ChartPeriod.DAY -> full.takeLast(5)
                        ChartPeriod.WEEK -> full.takeLast(7)
                        ChartPeriod.MONTH -> full.takeLast(30)
                    }

                    val lowest = data.minByOrNull { it.value }
                    val highest = data.maxByOrNull { it.value }

                    HistoricChartUiState(
                        selectedPeriod = period,
                        data = data,
                        unit = unit,
                        lowestValue = lowest?.value?.toInt() ?: 0,
                        lowestData = lowest?.dataLabel ?: "",
                        highestValue = highest?.value?.toInt() ?: 0,
                        highestData = highest?.dataLabel ?: "",
                        isLoading = false
                    )
                }
                .catch {
                    _uiState.value = HistoricChartUiState(isLoading = false)
                }
                .collect { _uiState.value = it }
        }
    }
}